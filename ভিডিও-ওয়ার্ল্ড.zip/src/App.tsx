import React, { useState, useEffect } from "react";
import { Post, CATEGORIES, SUB_CATEGORIES, getSubCategories } from "./types";
import { DEFAULT_POSTS, triggerAdRedirect } from "./data";
import { 
  Flame, Search, ChevronDown, Home, BookOpen, Video, ShieldCheck, 
  Play, Download, Award, Clock, Eye, Sparkles, Filter,
  Facebook, Send, MessageCircle, Menu, X, ThumbsUp, Share2
} from "lucide-react";
import AdminPanel from "./components/AdminPanel";
import PostDetailsModal from "./components/PostDetailsModal";
import { db } from "./lib/firebase";
import { collection, onSnapshot, setDoc, doc, deleteDoc, getDocs } from "firebase/firestore";

export default function App() {
  // Post states
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [activeLevel, setActiveLevel] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [currentPage, setCurrentPage] = useState<number>(1);
  
  // Modals & UI Toggles
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  
  // Dropdown states
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState<boolean>(false);
  const [isCommunityDropdownOpen, setIsCommunityDropdownOpen] = useState<boolean>(false);
  const [expandedMobileCategory, setExpandedMobileCategory] = useState<string | null>(null);

  // Read posts from Firestore
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "posts"), (snapshot) => {
      const postsData = snapshot.docs.map(doc => doc.data() as Post);
      setPosts(postsData);
      setIsLoading(false);
      
      // Keep a fallback or initial seeding if empty
      if (postsData.length === 0 && !localStorage.getItem("firebase_seeded")) {
        DEFAULT_POSTS.forEach(async (p) => {
          await setDoc(doc(db, "posts", p.id), p);
        });
        localStorage.setItem("firebase_seeded", "true");
      }
    }, (error) => {
      console.error("Error fetching posts: ", error);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Add or Edit a post
  const handleSavePost = async (savedPost: Post) => {
    try {
      await setDoc(doc(db, "posts", savedPost.id), savedPost);
    } catch (e) {
      console.error("Error saving post:", e);
    }
  };

  // Delete a post
  const handleDeletePost = async (id: string) => {
    try {
      await deleteDoc(doc(db, "posts", id));
    } catch (e) {
      console.error("Error deleting post:", e);
    }
  };

  // Reset to default posts
  const handleResetPosts = async () => {
    try {
      const snapshot = await getDocs(collection(db, "posts"));
      const deletePromises = snapshot.docs.map(doc => deleteDoc(doc.ref));
      await Promise.all(deletePromises);
      
      DEFAULT_POSTS.forEach(async (p) => {
        await setDoc(doc(db, "posts", p.id), p);
      });
    } catch (e) {
      console.error("Error resetting posts:", e);
    }
  };

  // Filter & Search Logic
  const filteredPosts = posts.filter(post => {
    const matchCategory = activeCategory === "all" || post.category === activeCategory;
    const matchLevel = activeLevel === "all" || post.level === activeLevel;
    const matchSearch = searchQuery.trim() === "" || 
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCategory && matchLevel && matchSearch;
  });

  // Sort by created time
  const sortedPosts = [...filteredPosts].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  // Pagination constraints (Max 5 posts per page)
  const POSTS_PER_PAGE = 5;
  const totalPages = Math.ceil(sortedPosts.length / POSTS_PER_PAGE) || 1;
  const startIndex = (currentPage - 1) * POSTS_PER_PAGE;
  const paginatedPosts = sortedPosts.slice(startIndex, startIndex + POSTS_PER_PAGE);

  // Reset page when category or search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [activeCategory, activeLevel, searchQuery]);

  // Click handler to open ad and show post details
  const handlePostClick = (post: Post) => {
    triggerAdRedirect(); // monetization trigger in a new tab!
    setSelectedPost(post); // still open the details inside video world!
  };

  // Like Action helper
  const handleLikeApp = async (post: Post, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const postRef = doc(db, "posts", post.id);
      await setDoc(postRef, { likes: (post.likes || 0) + 1 }, { merge: true });
    } catch (err) {
      console.error("Error liking post", err);
    }
  };

  // Share Action helper
  const handleShareApp = async (post: Post, e: React.MouseEvent) => {
    e.stopPropagation();
    const url = window.location.href; // Normally you might append ?post=id
    if (navigator.share) {
      try {
        await navigator.share({
          title: post.title,
          url: url
        });
      } catch (err: any) {
        if (err.name !== "AbortError") {
          console.error("Error sharing", err);
        }
      }
    } else {
      try {
        await navigator.clipboard.writeText(`${post.title} - ${url}`);
        alert("Link copied to clipboard!");
      } catch (err) {
        console.error("Error copying clipboard", err);
      }
    }
  };

  // Click play action helper
  const handlePlayAction = (post: Post, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerAdRedirect();
    setSelectedPost(post);
  };

  // Click download action helper
  const handleDownloadAction = (post: Post, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerAdRedirect();
    alert("আপনার ডাউনলোড সিকিউর লিঙ্ক জেনারেট হচ্ছে! অনুগ্রহ করে ডাউনলোড শুরু হওয়া পর্যন্ত অপেক্ষা করুন...");
    setTimeout(() => {
      const link = document.createElement("a");
      link.href = post.videoUrl !== "#" ? post.videoUrl : "https://www.w3schools.com/html/mov_bbb.mp4";
      link.download = `${post.title}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }, 1200);
  };

  // Get viral posts
  const viralPosts = posts.filter(p => p.isViral).slice(0, 5);

  // Get recent posts
  const recentPosts = [...posts].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  ).slice(0, 5);

  return (
    <div className="min-h-screen bg-[#0b0c10] text-[#f1f2f6] flex flex-col justify-between selection:bg-[#ff003c] selection:text-white relative overflow-x-hidden">
      
      {/* 1. HEADER SECTION */}
      <header className="sticky top-0 z-40 bg-[#0d0e15]/95 border-b border-[#ff003c]/20 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          
          {/* Logo Brand / Flame Logo */}
          <div 
            onClick={() => { setActiveCategory("all"); setActiveLevel("all"); setSearchQuery(""); }}
            className="flex items-center gap-2 cursor-pointer select-none group"
          >
            <div className="relative">
              <span className="text-3xl filter drop-shadow-[0_0_10px_rgba(255,0,60,0.8)] animate-pulse">🔥</span>
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#ff003c] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#ff003c]"></span>
              </span>
            </div>
            
            <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-white via-gray-100 to-[#ff003c] bg-clip-text text-transparent group-hover:scale-102 transition duration-200">
              ভিডিও ওয়ার্ল্ড
            </h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            <button
              onClick={() => { setActiveCategory("all"); setActiveLevel("all"); setSearchQuery(""); }}
              className="flex items-center gap-1.5 text-sm font-semibold text-gray-300 hover:text-white transition px-3.5 py-2 rounded-xl"
            >
              <span>হোম</span>
            </button>
            <div className="relative group/cat">
               <button className="flex items-center gap-1.5 text-sm font-semibold text-gray-300 hover:text-white transition px-3.5 py-2 rounded-xl">
                  <span>ক্যাটাগরি</span>
                  <ChevronDown size={14} />
               </button>
               <div className="absolute top-full left-0 hidden group-hover/cat:block bg-[#1c1e26] border border-gray-800 rounded-xl shadow-2xl py-2 min-w-[200px] z-50">
                  {CATEGORIES.map(cat => (
                    <div key={cat.key} className="relative group/sub">
                      <button 
                        onClick={() => { setActiveCategory(cat.key); setActiveLevel("all"); }}
                        className="w-full text-left px-4 py-2 text-xs hover:bg-gray-800 flex items-center justify-between"
                      >
                        {cat.label}
                        <ChevronDown size={12} className="-rotate-90" />
                      </button>
                      <div className="absolute left-full top-0 hidden group-hover/sub:block bg-[#1c1e26] border border-gray-800 rounded-xl shadow-2xl py-2 min-w-[220px] max-h-[350px] overflow-y-auto">
                        {getSubCategories(cat.key).map(lvl => (
                          <button
                            key={lvl}
                            onClick={() => { setActiveCategory(cat.key); setActiveLevel(lvl); }}
                            className="w-full text-left px-4 py-2.5 text-xs hover:bg-gray-800 leading-relaxed"
                          >
                            {lvl}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
               </div>
            </div>
          </nav>

          {/* Right side controls (Search & Menu Trigger) */}
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center w-72 relative">
              <input
                type="text"
                placeholder="ভিডিও বা গল্প খুঁজুন..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#1c1e26] border border-gray-800 focus:border-[#ff003c] text-xs px-3.5 py-2.5 pl-9 rounded-xl focus:outline-none text-white transition placeholder-gray-500"
              />
              <Search className="absolute left-3 text-gray-500" size={14} />
            </div>

            {/* Menu Trigger Button */}
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="p-2.5 bg-[#1c1e26] text-gray-300 hover:text-white rounded-xl border border-gray-800 hover:bg-gray-800 transition duration-200"
              aria-label="মেনুবার"
            >
              <Menu size={18} />
            </button>
          </div>
        </div>
      </header>

      {/* Slide-out Menu Drawer (closes on click outside overlay, slides right-to-left, left-aligned options) */}
      <div className={`fixed inset-0 z-[110] transition-all duration-300 ${isMobileMenuOpen ? "opacity-100 visible" : "opacity-0 invisible"}`}>
        {/* Backdrop Overlay */}
        <div 
          className="absolute inset-0 bg-black/80 backdrop-blur-md"
          onClick={() => setIsMobileMenuOpen(false)}
        />
        {/* Drawer Content Area (Opens upright vertically up to half the screen width on desktop or 85% on mobile) */}
        <div className={`absolute top-0 right-0 h-full w-[85%] md:w-[50%] max-w-[450px] bg-[#0d0e15] border-l border-gray-800 shadow-2xl flex flex-col transition-transform duration-300 transform ${isMobileMenuOpen ? "translate-x-0" : "translate-x-full"}`}>
          
          {/* Header */}
          <div className="p-6 flex items-center justify-between border-b border-gray-800 bg-[#0d0e15]/50 backdrop-blur-sm">
            <span className="font-bold text-white text-base tracking-wider uppercase flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff003c] animate-pulse"></span>
              মেনুবার
            </span>
            <button 
              onClick={() => setIsMobileMenuOpen(false)} 
              className="p-2 text-gray-400 hover:text-white hover:bg-gray-850 rounded-xl transition-all"
            >
              <X size={20} />
            </button>
          </div>

          {/* Drawer Links Area (Scrollable & Aligned Left) */}
          <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
            
            {/* 1. Home Section */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-850 pb-1.5 text-left">
                হোম
              </h4>
              <button
                onClick={() => { setActiveCategory("all"); setActiveLevel("all"); setSearchQuery(""); setIsMobileMenuOpen(false); }}
                className="w-full text-left py-2 px-3 text-sm font-semibold text-gray-300 hover:text-[#ff003c] rounded-lg hover:bg-gray-900 transition flex items-center gap-2"
              >
                <Home size={16} />
                <span>হোম পেজ</span>
              </button>
            </div>

            {/* 2. Categories Section */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-850 pb-1.5 text-left">
                ক্যাটাগরি
              </h4>
              <div className="flex flex-col gap-1 items-start w-full">
                {CATEGORIES.map(cat => {
                  const isExpanded = expandedMobileCategory === cat.key;
                  return (
                    <div key={cat.key} className="w-full">
                      <div className="flex w-full items-center">
                        <button
                          onClick={() => { setActiveCategory(cat.key); setActiveLevel("all"); setIsMobileMenuOpen(false); }}
                          className={`flex-1 text-left py-2 px-3 text-sm font-semibold rounded-l-lg transition ${activeCategory === cat.key ? "text-[#ff003c] bg-[#ff003c]/10" : "text-gray-300 hover:text-[#ff003c] hover:bg-gray-900"}`}
                        >
                          {cat.label}
                        </button>
                        <button 
                          onClick={() => setExpandedMobileCategory(isExpanded ? null : cat.key)}
                          className={`py-2 px-3 flex items-center justify-center rounded-r-lg transition ${(activeCategory === cat.key && !isExpanded) ? "bg-[#ff003c]/10 text-[#ff003c]" : "bg-gray-800/50 hover:bg-gray-800 text-gray-400"}`}
                        >
                          <ChevronDown size={14} className={`transition-transform duration-200 ${isExpanded ? "rotate-180" : ""}`} />
                        </button>
                      </div>
                      
                      {/* Dropdown Sub Categories */}
                      {isExpanded && (
                        <div className="flex flex-col gap-1 items-start mt-1 pl-4 border-l-2 border-gray-800 ml-2 max-h-[300px] overflow-y-auto pr-1">
                          {getSubCategories(cat.key).map(sub => (
                            <button
                              key={sub}
                              onClick={() => { setActiveCategory(cat.key); setActiveLevel(sub); setIsMobileMenuOpen(false); }}
                              className={`w-full text-left py-2.5 px-3 text-sm font-semibold rounded-lg transition ${activeLevel === sub ? "text-[#ff003c] bg-[#ff003c]/10" : "text-gray-400 hover:text-[#ff003c] hover:bg-gray-900"} leading-relaxed`}
                            >
                              {sub}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 4. Community Links Section */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-850 pb-1.5 text-left">
                আমাদের লিংক সমূহ
              </h4>
              <div className="flex flex-col gap-1 items-start">
                <a 
                  href="https://www.facebook.com/profile.php?id=61591104002454" 
                  target="_blank" 
                  rel="noreferrer" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-full text-left py-2 px-3 text-sm font-semibold text-gray-300 hover:text-[#ff003c] rounded-lg hover:bg-gray-900 transition flex items-center gap-2"
                >
                  <Facebook size={16} className="text-blue-500" />
                  <span>ফেসবুক পেজ</span>
                </a>
                <a 
                  href="https://m.me/j/AbYnW0SyGb4ZCu6D/?send_source=gc%3Acopy_invite_link_t" 
                  target="_blank" 
                  rel="noreferrer" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-full text-left py-2 px-3 text-sm font-semibold text-gray-300 hover:text-[#ff003c] rounded-lg hover:bg-gray-900 transition flex items-center gap-2"
                >
                  <MessageCircle size={16} className="text-blue-400" />
                  <span>মেসেঞ্জার গ্রুপ</span>
                </a>
                <a 
                  href="https://t.me/VideoWorldX" 
                  target="_blank" 
                  rel="noreferrer" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-full text-left py-2 px-3 text-sm font-semibold text-gray-300 hover:text-[#ff003c] rounded-lg hover:bg-gray-900 transition flex items-center gap-2"
                >
                  <Send size={16} className="text-sky-500" />
                  <span>টেলিগ্রাম চ্যানেল</span>
                </a>
                <a 
                  href="https://t.me/+cgZxBw7H_oJiMGJl" 
                  target="_blank" 
                  rel="noreferrer" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-full text-left py-2 px-3 text-sm font-semibold text-gray-300 hover:text-[#ff003c] rounded-lg hover:bg-gray-900 transition flex items-center gap-2"
                >
                  <Send size={16} className="text-sky-600" />
                  <span>টেলিগ্রাম গ্রুপ</span>
                </a>
                <a 
                  href="https://t.me/VideoWorldXBot" 
                  target="_blank" 
                  rel="noreferrer" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-full text-left py-2 px-3 text-sm font-semibold text-gray-300 hover:text-[#ff003c] rounded-lg hover:bg-gray-900 transition flex items-center gap-2"
                >
                  <Send size={16} className="text-sky-400" />
                  <span>টেলিগ্রাম বট</span>
                </a>
                <a 
                  href="https://whatsapp.com/channel/0029Vb8AjxR5fM5XNA2wlo0W" 
                  target="_blank" 
                  rel="noreferrer" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-full text-left py-2 px-3 text-sm font-semibold text-gray-300 hover:text-[#ff003c] rounded-lg hover:bg-gray-900 transition flex items-center gap-2"
                >
                  <MessageCircle size={16} className="text-green-500" />
                  <span>হোয়াটসঅ্যাপ চ্যানেল</span>
                </a>
                <a 
                  href="https://chat.whatsapp.com/L9hqWllhvmVIiUZwaRvdZG?s=cl&p=a&mlu=4&amv=0" 
                  target="_blank" 
                  rel="noreferrer" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-full text-left py-2 px-3 text-sm font-semibold text-gray-300 hover:text-[#ff003c] rounded-lg hover:bg-gray-900 transition flex items-center gap-2"
                >
                  <MessageCircle size={16} className="text-green-600" />
                  <span>হোয়াটসঅ্যাপ গ্রুপ</span>
                </a>
              </div>
            </div>

            {/* 5. Admin Panel */}
            <div className="pt-4 border-t border-gray-800">
              <button
                onClick={() => { setIsAdminOpen(true); setIsMobileMenuOpen(false); }}
                className="w-full text-left py-2.5 px-3 text-sm font-bold text-gray-300 hover:text-[#ff003c] rounded-lg bg-gray-900/40 hover:bg-gray-900 border border-gray-800 hover:border-gray-700 transition flex items-center gap-2"
              >
                <ShieldCheck size={16} className="text-[#ff003c]" />
                <span>এডমিন প্যানেল</span>
              </button>
            </div>

          </div>
        </div>
      </div>


      {/* Hero Announcement Ticker */}
      <section className="bg-red-600 overflow-hidden flex items-center">
        <div className="bg-green-600 text-white px-4 py-2 text-xs font-bold whitespace-nowrap z-10">সতর্কতা:</div>
        <div className="text-white text-xs font-medium py-2 animate-marquee whitespace-nowrap">
          ১৮+ ভিডিও ওয়ার্ল্ডে স্বাগতম! কোনো প্লে বা ডাউনলোড বাটনে ক্লিকের পর অন্য কোনো পেজে নিয়ে গেল ঘাবড়াবেন না, সেটি অ্যাড পেজ। এই পেজ থেকে ব্যাক করে ভিডিও দেখুন। স্বাচ্ছন্দ্যে সম্পূর্ণ বিনোদন ফ্রিতে উপভোগ করতে থাকুন।
        </div>
      </section>

      {/* CORE LAYOUT GRID (Main Area Grid System + Sidebar) */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Playable Grid Area - 8 columns */}
        <div id="main-content-region" className="lg:col-span-8 flex flex-col justify-between">
          
          {/* Posts Grid List */}
          <div className="space-y-6">
            {paginatedPosts.map((post, index) => {
              // Calculate global sequencial position e.g. "POST 01"
              const globalSeq = String(startIndex + index + 1).padStart(2, "0");
              const isVideo = post.category.startsWith("videos-");
              const categoryLabel = CATEGORIES.find(c => c.key === post.category)?.label || "জেনারেল";

              return (
                <article 
                  id={`post-card-${post.id}`}
                  key={post.id} 
                  className="bg-[#1c1e26] border border-gray-850 rounded-2xl overflow-hidden hover:border-[#ff003c]/40 hover:scale-[1.01] hover:shadow-2xl hover:shadow-[#ff003c]/5 transition-all duration-300 shadow-xl group flex flex-col md:flex-row relative"
                >
                  
                  {/* Top Badge (Sequential number) */}
                  <div className="absolute top-3 left-3 z-10">
                    <span className="bg-gradient-to-r from-[#ff003c] to-[#cc0030] text-white text-[11px] font-mono font-extrabold px-3 py-1 rounded-lg tracking-wider shadow-lg uppercase">
                      POST {filteredPosts.length - ((currentPage - 1) * POSTS_PER_PAGE + index)}
                    </span>
                  </div>

                  {/* Thumbnail Container 1:1 ratio */}
                  <div 
                    onClick={() => handlePostClick(post)}
                    className="w-full md:w-[320px] aspect-square relative overflow-hidden bg-[#0a0a0f] shrink-0 cursor-pointer"
                  >
                    <img 
                      src={post.image} 
                      alt={post.title} 
                      className="w-full h-full object-cover group-hover:scale-106 transition-transform duration-500"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&q=80";
                      }}
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Dark Overlay mask - removed to keep brightness full */}
                    <div className="absolute inset-0 group-hover:bg-black/10 transition-all duration-300" />

                    {/* Centered Big Red Play Button */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <button 
                        onClick={(e) => handlePlayAction(post, e)}
                        className="bg-[#ff003c] text-white p-3.5 rounded-full shadow-lg shadow-[#ff003c]/30 hover:bg-[#cc0030] focus:outline-none hover:scale-110 active:scale-95 transition-all duration-200 cursor-pointer flex-shrink-0"
                      >
                        <Play size={20} fill="currentColor" className="ml-0.5" />
                      </button>
                    </div>

                    {/* Duration Badge Bottom Right */}
                    <div className="absolute bottom-2.5 right-2.5">
                      <span className="bg-black/80 border border-gray-800 text-white font-mono text-[10px] font-semibold px-2 py-0.5 rounded flex items-center gap-1">
                        <Clock size={10} className="text-[#ff003c]" />
                        {post.duration}
                      </span>
                    </div>

                    {/* Left top subtle category label */}
                    <div className="absolute bottom-2.5 left-2.5">
                      <span className="bg-[#ff003c]/20 border border-[#ff003c]/40 text-[#ff003c] font-semibold text-[10px] px-2 py-0.5 rounded">
                        {categoryLabel}
                      </span>
                    </div>
                  </div>

                  {/* Content & Action Area */}
                  <div className="flex-1 p-5 flex flex-col justify-between">
                    
                    {/* Text Block */}
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-4 text-[11px] text-gray-500 font-mono flex-wrap">
                        <span className="flex items-center gap-1 text-gray-400">
                          <Eye size={12} className="text-[#ff003c]" />
                          {post.views.toLocaleString()} বার দেখা হয়েছে
                        </span>
                        <span>•</span>
                        <span>{new Date(post.createdAt).toLocaleDateString("bn-BD")}</span>
                        <div className="flex-1 min-w-[20px]" /> {/* Spacer */}
                        <button onClick={(e) => handleLikeApp(post, e)} className="flex items-center gap-1 text-gray-400 hover:text-[#ff003c] transition-colors">
                            <ThumbsUp size={12} /> {post.likes || 0}
                        </button>
                        <button onClick={(e) => handleShareApp(post, e)} className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors">
                            <Share2 size={12} /> শেয়ার
                        </button>
                      </div>

                      {/* Title Caption Bengali - Clickable */}
                      <h3 
                        onClick={() => handlePostClick(post)}
                        className="text-base md:text-lg font-bold text-white leading-snug hover:text-[#ff003c] transition-colors cursor-pointer select-text line-clamp-2"
                      >
                        {post.title}
                      </h3>
                    </div>

                    {/* Buttons Section - PLAY and DOWNLOAD */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-3 border-t border-gray-800/60">
                      <button
                        id={`post-btn-play-${post.id}`}
                        onClick={(e) => handlePlayAction(post, e)}
                        className="bg-green-600 hover:bg-green-700 active:scale-[0.98] text-white py-2 px-4 rounded-xl font-bold text-xs tracking-wide flex items-center justify-center gap-2 transition cursor-pointer"
                      >
                        <Play size={14} fill="currentColor" />
                        <span>Play Video</span>
                      </button>

                      <button
                        id={`post-btn-download-${post.id}`}
                        onClick={(e) => handleDownloadAction(post, e)}
                        className="bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white py-2 px-4 rounded-xl font-bold text-xs tracking-wide flex items-center justify-center gap-2 transition cursor-pointer"
                      >
                        <Download size={14} />
                        <span>Download Video</span>
                      </button>
                    </div>

                  </div>
                </article>
              );
            })}

            {paginatedPosts.length === 0 && (
              <div className="text-center py-16 bg-[#1c1e26] border border-gray-850 rounded-2xl">
                <span className="text-4xl">🔍</span>
                <h3 className="text-lg font-bold text-white mt-3">কোনো পোস্ট পাওয়া যায়নি</h3>
                <p className="text-gray-400 text-xs mt-1">অনুগ্রহ করে ভিন্ন কোনো শব্দ দিয়ে সার্চ করুন অথবা এডমিন ড্যাশবোর্ড থেকে পোস্ট যোগ করুন।</p>
                <button
                  onClick={() => { setActiveCategory("all"); setSearchQuery(""); }}
                  className="mt-4 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-xs font-semibold rounded-lg transition"
                >
                  ফিড রিসেট করুন
                </button>
              </div>
            )}
          </div>

          {/* Pagination Controls - Max 5 posts per page */}
          {totalPages > 1 && (
            <div id="feed-pagination" className="flex items-center justify-center gap-2 mt-8 py-4">
              
              {/* Prev Button */}
              {currentPage > 1 && (
                <button
                  onClick={() => { 
                    triggerAdRedirect(); 
                    setCurrentPage(prev => Math.max(prev - 1, 1)); 
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-4 h-9 flex items-center justify-center bg-[#1c1e26] border border-gray-800 rounded-xl text-xs font-bold text-gray-400 hover:text-white hover:border-gray-700 transition cursor-pointer"
                >
                  [« আগের পেজ]
                </button>
              )}

              {/* Individual Pages mapping */}
              {Array.from({ length: totalPages }).map((_, i) => {
                const pageNum = i + 1;
                return (
                  <button
                    key={pageNum}
                    onClick={() => { 
                      triggerAdRedirect(); 
                      setCurrentPage(pageNum); 
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`min-w-[36px] h-9 flex items-center justify-center rounded-xl text-xs font-bold transition border cursor-pointer ${
                      currentPage === pageNum
                        ? "bg-[#ff003c] border-[#ff003c] text-white shadow-lg shadow-[#ff003c]/20"
                        : "bg-[#1c1e26] border-gray-800 text-gray-400 hover:text-white hover:border-gray-700"
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              })}

              {/* Next Button */}
              {currentPage < totalPages && (
                <button
                  onClick={() => { 
                    triggerAdRedirect(); 
                    setCurrentPage(prev => Math.min(prev + 1, totalPages)); 
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-4 h-9 flex items-center justify-center bg-[#1c1e26] border border-gray-800 rounded-xl text-xs font-bold text-gray-400 hover:text-white hover:border-gray-700 transition cursor-pointer"
                >
                  [পরের পেজ »]
                </button>
              )}
            </div>
          )}

        </div>

        {/* SIDEBAR SECTIONS - 4 columns */}
        <aside id="sidebar-region" className="lg:col-span-4 space-y-6">
          
          {/* NEW POSTS WIDGET */}
          <div className="bg-[#1c1e26] border border-gray-850 rounded-2xl p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white border-b border-gray-800 pb-3 mb-4 flex items-center gap-2">
              <Clock size={15} className="text-[#ff003c]" />
              <span>নতুন ভিডিও</span>
            </h3>

            <div className="space-y-4">
              {recentPosts.slice(0, 5).map((r) => {
                return (
                  <div 
                    key={r.id}
                    onClick={() => handlePostClick(r)}
                    className="flex items-center gap-3 group cursor-pointer hover:bg-gray-800/20 hover:scale-[1.02] hover:shadow-lg p-2 -mx-2 rounded-xl transition-all"
                  >
                    <img 
                      src={r.image} 
                      alt={r.title} 
                      className="w-16 h-10 object-cover rounded-lg border border-gray-800 group-hover:opacity-80 transition flex-shrink-0"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&q=80";
                      }}
                    />
                    
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-gray-200 group-hover:text-[#ff003c] transition-colors line-clamp-2 leading-relaxed">
                        {r.title}
                      </h4>
                      <div className="flex items-center gap-2 mt-1 text-[9px] text-gray-500 font-mono">
                        <span className="px-1 py-0.2 bg-gray-800 rounded font-semibold text-gray-400">
                          {r.level}
                        </span>
                        <span>•</span>
                        <span>{new Date(r.createdAt).toLocaleDateString("bn-BD")}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* VIRAL POSTS WIDGET */}
          <div className="bg-[#1c1e26] border border-gray-850 rounded-2xl p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white border-b border-gray-800 pb-3 mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award size={15} className="text-amber-500 animate-bounce" />
                <span>ভাইরাল ভিডিও</span>
              </div>
              <span className="text-[10px] bg-amber-500/10 text-amber-500 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">Viral</span>
            </h3>

            <div className="space-y-3.5">
              {viralPosts.slice(0, 5).map((v) => (
                <div 
                  key={v.id}
                  onClick={() => handlePostClick(v)}
                  className="flex items-start gap-3 group cursor-pointer border-b border-gray-850/50 pb-3 last:border-0 hover:bg-gray-800/20 hover:scale-[1.02] hover:shadow-lg p-2 -mx-2 rounded-xl transition-all"
                >
                  <img 
                      src={v.image} 
                      alt={v.title} 
                      className="w-16 h-10 object-cover rounded-lg border border-gray-800 group-hover:opacity-80 transition flex-shrink-0"
                  />
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-gray-200 group-hover:text-[#ff003c] transition-colors leading-relaxed line-clamp-2">
                      {v.title}
                    </h4>
                    <div className="flex items-center gap-2 mt-1 text-[9px] text-gray-500 font-mono">
                      <span className="px-1 py-0.2 bg-gray-800 rounded font-semibold text-gray-400">
                        {v.level}
                      </span>
                      <span>•</span>
                      <span>{new Date(v.createdAt).toLocaleDateString("bn-BD")}</span>
                    </div>
                  </div>
                </div>
              ))}

              {viralPosts.length === 0 && (
                <div className="text-center py-4 text-xs text-gray-500">
                  কোনো ভাইরাল ভিডিও চিহ্নিত করা হয়নি!
                </div>
              )}
            </div>
          </div>

          {/* FOLLOW US WIDGET - Image 1 Style */}
          <div className="bg-[#1c1e26] border border-gray-850 rounded-2xl p-6 shadow-xl space-y-5">
            <h3 className="text-base font-bold text-white flex items-center gap-3">
              <span className="w-1.5 h-6 bg-[#ff003c] rounded-full"></span>
              FOLLOW US
            </h3>
            
            <div className="flex flex-col gap-3">
              <a 
                href="https://www.facebook.com/profile.php?id=61591104002454" 
                target="_blank" 
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-3 bg-[#3b5998] hover:bg-[#2d4373] text-white py-3.5 px-4 rounded-xl font-bold text-sm transition-all shadow-lg active:scale-[0.98]"
              >
                <Facebook size={18} />
                <span>ফেসবুক পেজ</span>
              </a>
              <a 
                href="https://m.me/j/AbYnW0SyGb4ZCu6D/?send_source=gc%3Acopy_invite_link_t" 
                target="_blank" 
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-3 bg-[#0084ff] hover:bg-[#0073e6] text-white py-3.5 px-4 rounded-xl font-bold text-sm transition-all shadow-lg active:scale-[0.98]"
              >
                <MessageCircle size={18} />
                <span>মেসেঞ্জার গ্রুপ</span>
              </a>
              <a 
                href="https://t.me/VideoWorldX" 
                target="_blank" 
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-3 bg-[#0088cc] hover:bg-[#006699] text-white py-3.5 px-4 rounded-xl font-bold text-sm transition-all shadow-lg active:scale-[0.98]"
              >
                <Send size={18} />
                <span>টেলিগ্রাম চ্যানেল</span>
              </a>
              <a 
                href="https://t.me/+cgZxBw7H_oJiMGJl" 
                target="_blank" 
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-3 bg-[#0088cc] hover:bg-[#006699] text-white py-3.5 px-4 rounded-xl font-bold text-sm transition-all shadow-lg active:scale-[0.98]"
              >
                <Send size={18} />
                <span>টেলিগ্রাম গ্রুপ</span>
              </a>
              <a 
                href="https://t.me/VideoWorldXBot" 
                target="_blank" 
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-3 bg-[#0088cc] hover:bg-[#006699] text-white py-3.5 px-4 rounded-xl font-bold text-sm transition-all shadow-lg active:scale-[0.98]"
              >
                <Send size={18} />
                <span>টেলিগ্রাম বট</span>
              </a>
              <a 
                href="https://whatsapp.com/channel/0029Vb8AjxR5fM5XNA2wlo0W" 
                target="_blank" 
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-3 bg-[#25D366] hover:bg-[#128C7E] text-white py-3.5 px-4 rounded-xl font-bold text-sm transition-all shadow-lg active:scale-[0.98]"
              >
                <MessageCircle size={18} />
                <span>হোয়াটসঅ্যাপ চ্যানেল</span>
              </a>
              <a 
                href="https://chat.whatsapp.com/L9hqWllhvmVIiUZwaRvdZG?s=cl&p=a&mlu=4&amv=0" 
                target="_blank" 
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-3 bg-[#25D366] hover:bg-[#128C7E] text-white py-3.5 px-4 rounded-xl font-bold text-sm transition-all shadow-lg active:scale-[0.98]"
              >
                <MessageCircle size={18} />
                <span>হোয়াটসঅ্যাপ গ্রুপ</span>
              </a>
            </div>
          </div>

        </aside>

      </main>

      {/* 3. FOOTER SECTION */}
      <footer className="bg-[#0b0c10] border-t border-gray-805/85 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          
          <div className="flex flex-col items-center text-center space-y-6">
            
            {/* Centered branding with large fire logo 🔥 */}
            <div className="flex items-center gap-2 select-none">
              <span className="text-5xl filter drop-shadow-[0_0_15px_rgba(255,0,60,0.8)] animate-pulse">🔥</span>
              <span className="text-3xl font-extrabold tracking-tight text-white">
                ভিডিও <span className="text-[#ff003c]">ওয়ার্ল্ড</span>
              </span>
            </div>

            {/* English description block */}
            <p className="max-w-2xl text-xs text-gray-400 leading-relaxed">
              ভিডিও ওয়ার্ল্ড একটি ফ্রি ভিডিও দেখার এবং বাংলা চটি গল্প পড়ার বাংলা প্ল্যাটফর্ম। এখনই প্রিমিয়াম বিনোদন উপভোগ করুন।
              সতর্কীকরণ: এখানে প্রকাশিত বিষয়বস্তু শুধুমাত্র বিনোদনের উদ্দেশ্যে এবং কেবলমাত্র ১৮+ প্রাপ্তবয়স্ক দর্শকদের জন্য।
            </p>

            {/* Nav anchors */}
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-gray-500">
              <button onClick={() => { setActiveCategory("all"); window.scrollTo({top:0, behavior:'smooth'}); }} className="hover:text-white transition">হোম পেজ</button>
              <span>•</span>
              <button onClick={() => { setActiveCategory("videos-desi"); window.scrollTo({top:0, behavior:'smooth'}); }} className="hover:text-white transition">দেশি ভিডিও</button>
              <span>•</span>
              <button onClick={() => { setActiveCategory("choti-mom"); window.scrollTo({top:0, behavior:'smooth'}); }} className="hover:text-white transition">মা-ছেলে চটি</button>
              <span>•</span>
              <button onClick={() => { triggerAdRedirect(); alert("নীতিমালা আপডেট হচ্ছে..."); }} className="hover:text-white transition">প্রাইভেসি পলিসি</button>
              <span>•</span>
              <button onClick={() => { triggerAdRedirect(); alert("আমাদের সাথে মেইল করুন: contact@videoworld.com"); }} className="hover:text-white transition">বিজ্ঞাপন দিন</button>
            </div>

            {/* Divider line */}
            <div className="w-full max-w-sm h-[1px] bg-gray-800/60" />

            {/* Copyright block */}
            <p className="text-[11px] text-gray-600 font-mono">
              © 2026 Video World. All Rights Reserved. Designed by UI/UX Specialist.
            </p>

          </div>

        </div>
      </footer>

      {/* 4. MODALS (Core interactive views) */}
      
      {/* Dynamic Pop-up Details Reader / Media Player Modal */}
      {selectedPost && (
        <PostDetailsModal
          post={selectedPost}
          onClose={() => setSelectedPost(null)}
          onRecentClick={(p) => setSelectedPost(p)}
          recentPosts={posts}
        />
      )}

      {/* Admin Panel Password Login & Config Dashboard */}
      <AdminPanel
        posts={posts}
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        onSavePost={handleSavePost}
        onDeletePost={handleDeletePost}
        onResetPosts={handleResetPosts}
      />

    </div>
  );
}
