export interface Post {
  id: string;
  image: string;
  videoUrl: string;
  duration: string;
  title: string;
  content: string;
  category: string;
  level: string; // Add level field
  createdAt: string;
  views: number;
  likes?: number;
  isViral: boolean;
}

export interface Comment {
  id: string;
  text: string;
  createdAt: string;
}

export interface CategoryInfo {
  key: string;
  label: string;
}

export const CATEGORIES: CategoryInfo[] = [
  { key: "videos", label: "ভিডিও" },
  { key: "choti", label: "চটি গল্প" },
];

const PREFIXES = [
  "মা ছেলের",
  "বাবা মেয়ের",
  "ভাই বোনের",
  "দেবর ভাবীর",
  "দুলাভাই শ্যালিকার",
  "স্বামী স্ত্রীর",
  "চাচা ভাতিজির",
  "চাচী ভাতিজার",
  "মামা ভাগ্নির",
  "মামী ভাগ্নের",
  "খালা ভাগ্নের",
  "খালু ভাগ্নির",
  "ফুফু ভাতিজার",
  "ফুফা ভাতিজির",
  "গার্লফ্রেন্ড বয়ফ্রেন্ডের",
  "ছাত্র ছাত্রীর",
  "শিক্ষক ছাত্রীর",
  "শিক্ষিকা ছাত্রের",
  "বস কর্মচারীর",
  "বাড়িওয়ালা ভাড়াটিয়ার",
  "ভাড়াটিয়া বাড়িওয়ালীর",
  "ডাক্তার রোগীর",
  "রোগী নার্সের",
  "সেলিব্রিটি ভক্তের",
  "বিদেশি স্থানীয়",
  "অনলাইন বন্ধু",
  "শৈশবের বন্ধু",
  "প্রতিবেশী",
  "পরকীয়ার",
  "ভ্রমণের",
  "ব্যবসায়িক পার্টনার",
  "জিম পার্টনার",
  "অফিসের কলিগ"
];

export const CHOTI_SUB_CATEGORIES = PREFIXES.map(p => `${p} চটি গল্প`);
export const VIDEO_SUB_CATEGORIES = PREFIXES.map(p => `${p} ভিডিও`);

// Fallback/combined for backwards compatibility if needed
export const SUB_CATEGORIES = [...VIDEO_SUB_CATEGORIES, ...CHOTI_SUB_CATEGORIES];

export function getSubCategories(categoryKey: string): string[] {
  if (categoryKey === "choti") {
    return CHOTI_SUB_CATEGORIES;
  }
  return VIDEO_SUB_CATEGORIES;
}

