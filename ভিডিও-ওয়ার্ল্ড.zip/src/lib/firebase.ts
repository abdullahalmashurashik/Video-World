import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyB2NR-zZS3e8cTUVIuPTviwREPVNRSWpcg",
  authDomain: "resonant-analyst-5dckx.firebaseapp.com",
  projectId: "resonant-analyst-5dckx",
  storageBucket: "resonant-analyst-5dckx.firebasestorage.app",
  messagingSenderId: "52665661397",
  appId: "1:52665661397:web:2296f64de707b707cb2f5c"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, "ai-studio-e3531212-30fa-4b01-bc64-c5c2c25be215");
